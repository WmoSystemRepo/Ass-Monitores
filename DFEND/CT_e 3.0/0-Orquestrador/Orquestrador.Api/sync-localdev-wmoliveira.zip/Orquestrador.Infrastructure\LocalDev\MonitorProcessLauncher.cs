using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Orquestrador.Application.Abstractions;
using Orquestrador.Application.Options;

namespace Orquestrador.Infrastructure.LocalDev;

/// <summary>
/// Implementação de <see cref="IMonitorProcessLauncher"/> para Development.
/// ProjectPath/FrontendProjectPath são relativos à raiz CT_e (descoberta automática;
/// prefixo absoluto da máquina é irrelevante).
/// </summary>
public sealed class MonitorProcessLauncher : IMonitorProcessLauncher, IDisposable
{
    private readonly IOptions<OrchestratorOptions> _options;
    private readonly IHostEnvironment _env;
    private readonly ILogger<MonitorProcessLauncher> _logger;
    private readonly ConcurrentDictionary<string, int> _launchedApiPids = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, int> _launchedFrontPids = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, byte> _apiLocks = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, byte> _frontLocks = new(StringComparer.OrdinalIgnoreCase);
    private readonly HttpClient _healthClient;
    private bool _disposed;

    public MonitorProcessLauncher(
        IOptions<OrchestratorOptions> options,
        IHostEnvironment env,
        ILogger<MonitorProcessLauncher> logger)
    {
        _options = options;
        _env = env;
        _logger = logger;
        _healthClient = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
    }

    /// <inheritdoc />
    public Task<bool> IsApiReadyAsync(string baseUrl, CancellationToken ct)
    {
        return IsHttpOkAsync(Combine(baseUrl, "/health/ready"), ct);
    }

    /// <inheritdoc />
    public Task<bool> IsFrontendReachableAsync(string frontendUrl, CancellationToken ct)
    {
        return IsHttpOkAsync(frontendUrl.Trim().TrimEnd('/'), ct);
    }

    /// <inheritdoc />
    public async Task<bool> EnsureApiReadyAsync(OrchestratorSystemOptions system, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(system.BaseUrl))
        {
            return false;
        }

        if (await IsApiReadyAsync(system.BaseUrl, ct).ConfigureAwait(false))
        {
            return true;
        }

        if (!_env.IsDevelopment())
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(system.ProjectPath))
        {
            _logger.LogWarning(
                "Monitor {Id} offline e sem ProjectPath — não é possível auto-start.",
                system.Id);
            return false;
        }

        var timeoutSeconds = Math.Max(5, _options.Value.LocalDev.StartupTimeoutSeconds);

        if (!_apiLocks.TryAdd(system.Id, 0))
        {
            return await WaitUntilAsync(
                () => IsApiReadyAsync(system.BaseUrl, ct),
                timeoutSeconds,
                ct).ConfigureAwait(false);
        }

        try
        {
            if (await IsApiReadyAsync(system.BaseUrl, ct).ConfigureAwait(false))
            {
                return true;
            }

            if (!TryResolveFilePath(system.ProjectPath, out var projectPath, out var resolveError))
            {
                _logger.LogWarning(
                    "Não foi possível resolver ProjectPath do {Id}: {Error}",
                    system.Id,
                    resolveError);
                return false;
            }

            if (!TryStartMonitorApi(system, projectPath, out var startError))
            {
                _logger.LogWarning("Falha ao iniciar Monitor.Api {Id}: {Error}", system.Id, startError);
                return false;
            }

            _logger.LogInformation(
                "Monitor.Api {Id} iniciado ({Project}). Aguardando /health/ready em {BaseUrl}…",
                system.Id,
                projectPath,
                system.BaseUrl);

            var ready = await WaitUntilAsync(
                () => IsApiReadyAsync(system.BaseUrl, ct),
                timeoutSeconds,
                ct).ConfigureAwait(false);

            if (!ready)
            {
                _logger.LogWarning(
                    "Monitor.Api {Id} não ficou ready em {Timeout}s (processo pode ter subido sem SQL).",
                    system.Id,
                    timeoutSeconds);
            }

            return ready;
        }
        finally
        {
            _apiLocks.TryRemove(system.Id, out _);
        }
    }

    /// <inheritdoc />
    public async Task<bool> EnsureFrontendAsync(OrchestratorSystemOptions system, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(system.FrontendUrl))
        {
            return false;
        }

        if (await IsFrontendReachableAsync(system.FrontendUrl, ct).ConfigureAwait(false))
        {
            return true;
        }

        if (!_env.IsDevelopment())
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(system.FrontendProjectPath))
        {
            _logger.LogWarning(
                "Frontend {Id} offline e sem FrontendProjectPath — não é possível auto-start.",
                system.Id);
            return false;
        }

        var timeoutSeconds = Math.Max(60, _options.Value.LocalDev.StartupTimeoutSeconds);

        if (!_frontLocks.TryAdd(system.Id, 0))
        {
            return await WaitUntilAsync(
                () => IsFrontendReachableAsync(system.FrontendUrl!, ct),
                timeoutSeconds,
                ct).ConfigureAwait(false);
        }

        try
        {
            if (await IsFrontendReachableAsync(system.FrontendUrl, ct).ConfigureAwait(false))
            {
                return true;
            }

            if (!TryResolveDirectoryPath(system.FrontendProjectPath, out var frontendDir, out var resolveError))
            {
                _logger.LogWarning(
                    "Não foi possível resolver FrontendProjectPath do {Id}: {Error}",
                    system.Id,
                    resolveError);
                return false;
            }

            if (!TryStartFrontend(system, frontendDir, out var startError))
            {
                _logger.LogWarning("Falha ao iniciar frontend {Id}: {Error}", system.Id, startError);
                return false;
            }

            _logger.LogInformation(
                "Frontend {Id} iniciado em {Dir}. Aguardando {Url}…",
                system.Id,
                frontendDir,
                system.FrontendUrl);

            var ready = await WaitUntilAsync(
                () => IsFrontendReachableAsync(system.FrontendUrl!, ct),
                timeoutSeconds,
                ct).ConfigureAwait(false);

            if (!ready)
            {
                _logger.LogWarning(
                    "Frontend {Id} não respondeu em {Timeout}s em {Url}.",
                    system.Id,
                    timeoutSeconds,
                    system.FrontendUrl);
            }

            return ready;
        }
        finally
        {
            _frontLocks.TryRemove(system.Id, out _);
        }
    }

    private bool TryStartMonitorApi(
        OrchestratorSystemOptions system,
        string projectPath,
        out string? error)
    {
        error = null;

        try
        {
            var urls = system.BaseUrl.Trim().TrimEnd('/');
            var workDir = Path.GetDirectoryName(projectPath)!;
            var dllPath = Path.Combine(workDir, "bin", "Debug", "net8.0", "Monitor.Api.dll");

            ProcessStartInfo psi;
            if (File.Exists(dllPath))
            {
                psi = new ProcessStartInfo
                {
                    FileName = "dotnet",
                    Arguments = $"\"{dllPath}\"",
                    WorkingDirectory = Path.GetDirectoryName(dllPath)!,
                    UseShellExecute = false,
                    CreateNoWindow = false,
                };
            }
            else
            {
                psi = new ProcessStartInfo
                {
                    FileName = "dotnet",
                    Arguments = $"run --project \"{projectPath}\" --no-launch-profile",
                    WorkingDirectory = workDir,
                    UseShellExecute = false,
                    CreateNoWindow = false,
                };
            }

            psi.Environment["ASPNETCORE_ENVIRONMENT"] = "Development";
            psi.Environment["ASPNETCORE_URLS"] = urls;

            var process = System.Diagnostics.Process.Start(psi);
            if (process is null)
            {
                error = "Process.Start retornou null.";
                return false;
            }

            _launchedApiPids[system.Id] = process.Id;
            Thread.Sleep(500);
            if (process.HasExited)
            {
                error = $"Processo saiu imediatamente (exit={process.ExitCode}). Compile o Monitor.Api primeiro.";
                return false;
            }

            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    private bool TryStartFrontend(
        OrchestratorSystemOptions system,
        string frontendDir,
        out string? error)
    {
        error = null;

        try
        {
            var title = $"CT-e Front {system.DisplayName}";
            var psi = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/c start \"{title}\" /D \"{frontendDir}\" cmd /k npm.cmd start",
                UseShellExecute = false,
                CreateNoWindow = true,
            };

            var process = System.Diagnostics.Process.Start(psi);
            if (process is null)
            {
                error = "Process.Start (frontend) retornou null.";
                return false;
            }

            _launchedFrontPids[system.Id] = process.Id;
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }

    private bool TryResolveFilePath(string configured, out string absolutePath, out string? error)
    {
        var root = ResolveRepoRoot();
        return CtePathResolver.TryResolveFile(configured, root, out absolutePath, out error);
    }

    private bool TryResolveDirectoryPath(string configured, out string absolutePath, out string? error)
    {
        var root = ResolveRepoRoot();
        return CtePathResolver.TryResolveDirectory(configured, root, out absolutePath, out error);
    }

    /// <summary>
    /// Pasta CT_e (contém 0-Orquestrador). Prefixo da máquina é irrelevante —
    /// descoberta sobe a partir do ContentRoot / cwd / BaseDirectory.
    /// </summary>
    private string? ResolveRepoRoot()
    {
        var configured = _options.Value.LocalDev.RepoRoot;
        var root = CtePathResolver.ResolveRepoRoot(configured, _env.ContentRootPath);
        if (root is null && !string.IsNullOrWhiteSpace(configured))
        {
            _logger.LogWarning(
                "LocalDev:RepoRoot inválido ou de outra máquina ({RepoRoot}). Usando descoberta automática a partir de Orquestrador.Api.",
                configured);
        }
        else if (root is not null)
        {
            _logger.LogDebug("LocalDev RepoRoot resolvido: {RepoRoot}", root);
        }

        return root;
    }

    private static async Task<bool> WaitUntilAsync(
        Func<Task<bool>> probe,
        int timeoutSeconds,
        CancellationToken ct)
    {
        var timeout = TimeSpan.FromSeconds(Math.Clamp(timeoutSeconds, 5, 300));
        var deadline = DateTimeOffset.UtcNow + timeout;

        while (DateTimeOffset.UtcNow < deadline)
        {
            ct.ThrowIfCancellationRequested();
            if (await probe().ConfigureAwait(false))
            {
                return true;
            }

            await Task.Delay(1000, ct).ConfigureAwait(false);
        }

        return false;
    }

    private async Task<bool> IsHttpOkAsync(string url, CancellationToken ct)
    {
        try
        {
            using var response = await _healthClient.GetAsync(url, ct).ConfigureAwait(false);
            return (int)response.StatusCode < 500;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or IOException)
        {
            return false;
        }
    }

    private static string Combine(string baseUrl, string path) =>
        $"{baseUrl.TrimEnd('/')}/{path.TrimStart('/')}";

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        _healthClient.Dispose();
    }
}
